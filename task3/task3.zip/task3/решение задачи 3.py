import processing
from qgis.PyQt.QtCore import QVariant
from qgis.core import (
    QgsProcessing, QgsProcessingAlgorithm, QgsProcessingParameterFeatureSource,
    QgsProcessingParameterPoint, QgsProcessingParameterFeatureSink,
    QgsProcessingParameterNumber, QgsFeature, QgsGeometry, QgsField,
    QgsFields, QgsWkbTypes, QgsCoordinateTransform, QgsProject
)

class ShortestPathTypenoAlgorithm(QgsProcessingAlgorithm):
    INPUT = 'INPUT'
    START = 'START'
    END = 'END'
    TOLERANCE = 'TOLERANCE'
    TRANSPORT = 'TRANSPORT'
    OUTPUT = 'OUTPUT'
    
    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.INPUT, 'Слой дорог (TYPENO / R_TYPENO)',
            [QgsProcessing.TypeVectorLine]
        ))
        self.addParameter(QgsProcessingParameterPoint(self.START, 'Начальная точка'))
        self.addParameter(QgsProcessingParameterPoint(self.END, 'Конечная точка'))
        self.addParameter(QgsProcessingParameterNumber(
            self.TOLERANCE, 'Допуск привязки (м)',
            QgsProcessingParameterNumber.Double, defaultValue=50, minValue=0
        ))
        self.addParameter(QgsProcessingParameterNumber(
            self.TRANSPORT,
            'Тип транспорта: 1=авто, 2=велосипед, 3=пешком',
            QgsProcessingParameterNumber.Integer,
            defaultValue=1,
            minValue=1,
            maxValue=3
        ))
        self.addParameter(QgsProcessingParameterFeatureSink(
            self.OUTPUT, 'Кратчайший путь'
        ))

    def processAlgorithm(self, params, context, feedback):
        source = self.parameterAsSource(params, self.INPUT, context)
        raw_start = self.parameterAsPoint(params, self.START, context)
        raw_end = self.parameterAsPoint(params, self.END, context)
        tolerance = self.parameterAsDouble(params, self.TOLERANCE, context)
        transport = self.parameterAsInt(params, self.TRANSPORT, context)

        # Определяем тип транспорта и соответствующие символы
        if transport == 1:
            transport_char = 'A'  # автомобиль
        elif transport == 2:
            transport_char = 'V'  # велосипед
        elif transport == 3:
            transport_char = 'P'  # пешком
        else:
            feedback.reportError("❗ Ошибка: неизвестный тип транспорта")
            return {}

        # CRS преобразование
        prj_crs = context.project().crs()
        src_crs = source.sourceCrs()
        if prj_crs.isValid() and prj_crs != src_crs:
            tr = QgsCoordinateTransform(prj_crs, src_crs, context.project())
            start_pt = tr.transform(raw_start)
            end_pt = tr.transform(raw_end)
        else:
            start_pt = raw_start
            end_pt = raw_end

        # Проверяем наличие необходимых полей
        fields = [f.name().upper() for f in source.fields()]
        if 'TYPENO' not in fields or 'R_TYPENO' not in fields:
            feedback.reportError("❌ В слое нет полей TYPENO / R_TYPENO")
            return {}
        
        # Проверяем наличие полей TSYSSET/R_TSYSSET для фильтрации по транспорту
        has_tsysset = 'TSYSSET' in fields or 'TSYSSET' in [f.name() for f in source.fields()]
        has_r_tsyset = 'R_TSYSSET' in fields or 'R_TSYSSET' in [f.name() for f in source.fields()]

        # Создаем выражение для фильтрации дорог по транспорту
        if has_tsysset and has_r_tsyset:
            # Если есть поля TSYSSET и R_TSYSSET, учитываем транспорт
            expr = f"""
CASE
    -- Проверяем наличие транспорта в прямом направлении
    WHEN (("TYPENO" <> 0 AND "TYPENO" <> '0') AND 
          (UPPER("TSYSSET") LIKE '%{transport_char}%' OR "TSYSSET" IS NULL OR "TSYSSET" = ''))
     AND (("R_TYPENO" <> 0 AND "R_TYPENO" <> '0') AND 
          (UPPER("R_TSYSSET") LIKE '%{transport_char}%' OR "R_TSYSSET" IS NULL OR "R_TSYSSET" = '')) 
     THEN 'BOTH'
    
    WHEN (("TYPENO" <> 0 AND "TYPENO" <> '0') AND 
          (UPPER("TSYSSET") LIKE '%{transport_char}%' OR "TSYSSET" IS NULL OR "TSYSSET" = '')) 
     THEN 'FWD'
    
    WHEN (("R_TYPENO" <> 0 AND "R_TYPENO" <> '0') AND 
          (UPPER("R_TSYSSET") LIKE '%{transport_char}%' OR "R_TSYSSET" IS NULL OR "R_TSYSSET" = '')) 
     THEN 'BWD'
    
    ELSE 'CLOSED'
END
"""
        else:
            # Если нет полей TSYSSET, используем только TYPENO/R_TYPENO
            feedback.pushInfo("⚠️ Поля TSYSSET/R_TSYSSET отсутствуют. Используются только TYPENO/R_TYPENO.")
            expr = """
CASE
    WHEN ("TYPENO" <> 0 AND "TYPENO" <> '0')
     AND ("R_TYPENO" <> 0 AND "R_TYPENO" <> '0') THEN 'BOTH'
    
    WHEN ("TYPENO" <> 0 AND "TYPENO" <> '0') THEN 'FWD'
    
    WHEN ("R_TYPENO" <> 0 AND "R_TYPENO" <> '0') THEN 'BWD'
    
    ELSE 'CLOSED'
END
"""

        # Применяем фильтр с помощью Field Calculator
        fc_params = {
            'INPUT': params[self.INPUT],
            'FIELD_NAME': 'dir_flag',
            'FIELD_TYPE': 2,  # String
            'FIELD_LENGTH': 10,
            'FORMULA': expr,
            'OUTPUT': 'memory:prepared'
        }
        
        prepared = processing.run('native:fieldcalculator', fc_params,
                                 context=context, feedback=feedback)['OUTPUT']

        # Строим маршрут с учетом направлений
        sp_params = {
            'INPUT': prepared,
            'STRATEGY': 0,  # кратчайший путь
            'DIRECTION_FIELD': 'dir_flag',
            'VALUE_FORWARD': 'FWD',
            'VALUE_BACKWARD': 'BWD',
            'VALUE_BOTH': 'BOTH',
            'DEFAULT_DIRECTION': 2,  # оба направления
            'SPEED_FIELD': '',
            'DEFAULT_SPEED': 50,
            'TOPOLOGY_TOLERANCE': tolerance,
            'START_POINT': f'{start_pt.x()},{start_pt.y()}',
            'END_POINT': f'{end_pt.x()},{end_pt.y()}',
            'OUTPUT': 'memory:route'
        }

        result = processing.run('native:shortestpathpointtopoint', sp_params,
                               context=context, feedback=feedback)
        route = result['OUTPUT']

        # Подготавливаем выходной слой
        sink_fields = QgsFields()
        sink_fields.append(QgsField('transport', QVariant.String))
        sink_fields.append(QgsField('length_m', QVariant.Double))
        
        sink, dest_id = self.parameterAsSink(
            params, self.OUTPUT, context, sink_fields,
            QgsWkbTypes.LineString, src_crs
        )

        if route.featureCount() == 0:
            feedback.reportError("⚠️ Маршрут не найден. Проверьте параметры транспорта и доступные дороги.")
            return {self.OUTPUT: dest_id}

        # Объединяем геометрии в одну линию
        features = list(route.getFeatures())
        if features:
            geom = features[0].geometry()
            for feat in features[1:]:
                geom = geom.combine(feat.geometry())
            
            # Создаем фичу с результатом
            out_feature = QgsFeature(sink_fields)
            out_feature.setGeometry(geom)
            
            transport_names = {1: 'автомобиль', 2: 'велосипед', 3: 'пешком'}
            out_feature.setAttributes([
                transport_names.get(transport, str(transport)),
                round(geom.length(), 2)
            ])
            
            sink.addFeature(out_feature)
            feedback.pushInfo(f"✅ Маршрут построен! Тип транспорта: {transport_names.get(transport)}, Длина: {geom.length():.2f} м")

        return {self.OUTPUT: dest_id}

    def name(self):
        return 'shortest_path_typeno_transport'

    def displayName(self):
        return 'Кратчайший путь (TYPENO + транспорт)'

    def group(self):
        return 'Custom'

    def groupId(self):
        return 'custom'

    def createInstance(self):
        return ShortestPathTypenoAlgorithm()